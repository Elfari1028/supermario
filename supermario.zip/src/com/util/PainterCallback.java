package com.util;

import java.awt.Graphics;
public interface PainterCallback {
    public void addPainter(Graphics g);
}
