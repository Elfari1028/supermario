package com.role;
import java.awt.Image;

public class Trap extends Enemy{
    public Trap(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}
