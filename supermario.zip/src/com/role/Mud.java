package com.role;
import java.awt.Image;
//泥土类
public class Mud extends Enemy {
    public Mud(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}
