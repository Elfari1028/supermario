package com.role;

import java.awt.Image;

public class Brick extends Enemy {
    public Brick(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}
