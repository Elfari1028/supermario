package com.role;
import java.awt.Image;

public class Flag extends Enemy {
    public Flag(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}
