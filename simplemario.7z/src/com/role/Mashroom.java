package com.role;
import java.awt.Image;

public class Mashroom extends Enemy{
    public Mashroom(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}
